export const THEMES = [
  { id: 1, emoji: "🇻🇳", title: "Giải Phóng 30/4", desc: "Hào khí quân giải phóng, rợp bóng cờ Tổ Quốc." },
  { id: 2, emoji: "🏔️", title: "Điện Biên Phủ", desc: "Chấn động địa cầu, hầm De Castries oai hùng." },
  { id: 3, emoji: "🌿", title: "Đường Mòn HCM", desc: "Trường Sơn huyền thoại, xe tải không kính." },
  { id: 4, emoji: "🏰", title: "Thành Cổ Quảng Trị", desc: "Mùa hè đỏ lửa 1972, ý chí thép bất tử." },
  { id: 5, emoji: "✈️", title: "Không Quân", desc: "Cánh én bạc bảo vệ bầu trời thủ đô." },
  { id: 6, emoji: "⚓", title: "Trường Sa - Hoàng Sa", desc: "Cột mốc chủ quyền, vững tay súng giữa biển." },
  { id: 7, emoji: "🧣", title: "Nữ Kiệt", desc: "Nữ du kích, TNXP rạng ngời thời chiến." },
  { id: 8, emoji: "🔥", title: "TN Xung Phong", desc: "Hỏa tuyến rực lửa, tuổi trẻ cống hiến." },
  { id: 9, emoji: "🛡️", title: "Đặc Công", desc: "Rừng Sác huyền thoại, sức mạnh thầm lặng." },
  { id: 10, emoji: "💣", title: "Pháo Binh", desc: "Voi sắt gầm vang, hỏa lực ngút trời." },
  { id: 11, emoji: "🕰️", title: "Hà Nội 12 Ngày Đêm", desc: "Điện Biên Phủ trên không, lòng người sắt đá." },
  { id: 12, emoji: "🤴", title: "Quốc Phục Vua Hùng", desc: "Hùng Vương, Lý, Trần - Tinh hoa di sản." },
  { id: 13, emoji: "🚣", title: "Nam Bộ Kháng Chiến", desc: "Ghe xuồng hỏa tuyến, hào sảng miền Tây." },
  { id: 14, emoji: "🛖", title: "Chiến Khu Việt Bắc", desc: "Thủ đô kháng chiến, mái đình Hồng Thái." },
  { id: 15, emoji: "🚢", title: "Hải Quân", desc: "Tàu không số, đường mòn trên biển anh dũng." },
  { id: 16, emoji: "📡", title: "Thông Tin Liên Lạc", desc: "Mạch máu chiến trường, bền bỉ kết nối." },
  { id: 17, emoji: "🩺", title: "Quân Y", desc: "Tận tâm cứu chữa trong bom đạn." },
  { id: 18, emoji: "🐘", title: "Hai Bà Trưng", desc: "Cưỡi voi đánh giặc, bảo vệ non sông." },
  { id: 19, emoji: "⚔️", title: "Hào Khí Đông A", desc: "Bạch Đằng vang dội, ý chí Sát Thát." },
  { id: 20, emoji: "🏟️", title: "Ngày Độc Lập 1945", desc: "Ba Đình rực rỡ, bản tuyên ngôn lịch sử." }
];

export const SUB_CONCEPTS: Record<number, string[]> = {};

THEMES.forEach(t => {
  const shortTitle = t.title.length > 20 ? t.title.substring(0, 20) + ".." : t.title;

  SUB_CONCEPTS[t.id] = [
    `💎 Siêu phẩm ${shortTitle} Neon 3D Luxury`,
    `🇻🇳 Tự hào Cờ Đỏ Sao Vàng - ${shortTitle} VIP`,
    `✨ Hào quang Độc Lập - ${shortTitle} 8K`,
    `🔥 Chiến thắng Điện Biên - ${shortTitle} Epic`,
    `🐉 Tinh hoa Đất Việt - ${shortTitle} Hoàng Gia`,
    `🚩 Khải hoàn môn - ${shortTitle} Rực rỡ`,
    `🌟 Ngôi sao Phương Đông - ${shortTitle} 3D`,
    `🕊️ Hòa bình muôn năm - ${shortTitle} Tinh khiết`,
    `🏺 Di sản ngàn năm - ${shortTitle} Cinematic`,
    `❤️ Biết ơn Tổ quốc - ${shortTitle} Cảm động`
  ];
});

export const MENS_WEAR = [
  "⛔ Không chọn", 
  "👕 Áo thun Đỏ Sao Vàng VIP (Ngôi sao lớn chính diện ngực)", 
  "👕 Áo thun Trắng Sao Vàng VIP (Ngôi sao lớn chính diện ngực)",
  "👔 Áo dài Đỏ Tươi trơn truyền thống (Cờ Sao Vàng chính diện ngực)",
  "👔 Áo dài Trắng trơn truyền thống (Cờ Sao Vàng chính diện ngực)",
  "👔 Áo dài Đỏ Tươi trơn truyền thống (Không hoa văn, lụa cao cấp)",
  "👔 Áo dài Trắng trơn truyền thống (Không hoa văn, lụa cao cấp)",
  "👕 Áo Bà Ba Sám (Dáng truyền thống, vạt ngang hông, cúc dọc)",
  "👕 Áo Bà Ba Đen (Dáng truyền thống, vạt ngang hông, cúc dọc)",
  "👕 Áo Bà Ba Đỏ (Dáng truyền thống, vạt ngang hông, cúc dọc)",
  "👕 Áo Bà Ba Trắng (Dáng truyền thống, vạt ngang hông, cúc dọc)",
  "🧥 Vest Lãnh đạo sang trọng thêu chim lạc", 
  "🧥 Suit Ý cao cấp Red-Gold", 
  "👔 Sơ mi trắng lịch lãm (Divine White)", 
  "🧥 Blazer Nhung Đỏ Bordeaux VIP", 
  "🧥 Áo măng tô Đỏ quý tộc", 
  "🧥 Áo khoác da phi công 1975", 
  "👔 Suit 3 mảnh quý tộc Trống Đồng", 
  "👔 Sơ mi Trống Đồng 3D Gold VIP", 
  "👔 Vest trắng thảm đỏ VIP Quốc tế"
];

export const WOMENS_WEAR = [
  "⛔ Không chọn", 
  "👚 Áo dài Đỏ Tươi trơn truyền thống (Cờ Sao Vàng chính diện ngực VIP)",
  "👚 Áo dài Trắng trơn truyền thống (Cờ Sao Vàng chính diện ngực VIP)",
  "👚 Áo dài Đỏ Tươi trơn truyền thống (Không hoa văn, lụa cao cấp)",
  "👚 Áo dài Trắng trơn truyền thống (Không hoa văn, lụa cao cấp)",
  "🧣 Áo Bà Ba Sám (Vạt ngang hông, cúc dọc, chuẩn Việt Nam)",
  "🧣 Áo Bà Ba Đen (Vạt ngang hông, cúc dọc, chuẩn Việt Nam)",
  "🧣 Áo Bà Ba Đỏ (Vạt ngang hông, cúc dọc, chuẩn Việt Nam)",
  "🧣 Áo Bà Ba Trắng (Vạt ngang hông, cúc dọc, chuẩn Việt Nam)",
  "👕 Áo thun cổ tròn Đỏ (Sao vàng to trước ngực)",
  "👕 Áo thun cổ tròn Trắng (Sao vàng to trước ngực)",
  "👚 Áo thun Cờ Đỏ Nữ (Dáng xinh VIP)", 
  "👗 Áo dài Đỏ Tươi Phượng Hoàng Châu Âu", 
  "👚 Áo dài Trắng gấm Luxury (Hoàng Gia)", 
  "👚 Áo dài lụa Tuyết Trắng tinh khiết",
  "👚 Áo dài lụa Đỏ quyền lực vương giả", 
  "👚 Áo dài Trống Đồng VIP Gold 3D", 
  "💃 Đầm Red-Gold Gala lộng lẫy Quốc tế", 
  "👗 Áo dài Nhung Đỏ thượng lưu quý xộc", 
  "👗 Váy lụa đỏ dập ly cao cấp VIP",
  "💃 Đầm Thảm đỏ Cờ Đỏ VIP rạng ngời", 
  "👗 Áo dài Cổ trụ trắng Trinh Nguyên", 
  "👑 Áo dài Nam Phương Luxury Silk"
];

export const BACKGROUNDS = [
  "⛔ Không chọn", 
  "✨ Sự giao thoa: Ký ức Chiến trường & Landmark 81", 
  "✨ Bản giao hưởng: Thành cổ & Phố thị hiện đại",
  "✨ Ánh hào quang: Đường mòn HCM & Cầu Vàng",
  "✨ Chuyển mình: Dinh Độc Lập bừng sáng tương lai",
  "🔥 Điện Biên Phủ - Lừng lẫy năm châu, chấn động địa cầu",
  "🔥 Thành cổ Quảng Trị - 81 ngày đêm đỏ lửa anh hùng",
  "🔥 Đường Trường Sơn - Mạch máu huyền thoại Tổ quốc",
  "🔥 Căn cứ Khe Sanh - Hỏa trận rực lửa Trường Sơn",
  "🔥 Ngã ba Đồng Lộc - Những đóa hoa bất tử",
  "🔥 Địa đạo Củ Chi - Kỳ tích trong lòng đất",
  "🔥 Cầu Hàm Rồng - Cây cầu thép bất khuất",
  "🔥 Trận chiến Hà Nội 12 ngày đêm (B52)",
  "🔥 Cửa ngõ Sài Gòn - Thần tốc giải phóng 1975",
  "🏙️ Landmark 81 - Niềm tự hào cao nhất Việt Nam",
  "🏙️ Bitexco - Biểu tượng búp sen rạng rỡ",
  "🏙️ Lotte Center Hanoi - Tầm cao tinh hoa",
  "🏙️ Cầu Thủ Thiêm 2 - Dòng chảy hiện đại Sài Gòn",
  "🏙️ Phố đi bộ Nguyễn Huệ - Phồn hoa đô hội",
  "🏙️ Vinhome Central Park - Không gian sống tỷ phú",
  "🗼 Cầu Rồng Đà Nẵng - Rồng thiêng phun lửa",
  "🏛️ Tòa nhà Quốc Hội - Uy nghiêm và Quyền lực",
  "🏛️ Nhà hát Lớn Hà Nội - Kiến trúc di sản Luxury",
  "⛲ Chùa Một Cột - Biểu tượng văn hóa tâm linh",
  "📜 Văn Miếu Quốc Tử Giám - Tinh hoa đạo học",
  "🎡 Vòng quay Mặt Trời (Sun Wheel) rực rỡ",
  "🏟️ Sân vận động Quốc gia Mỹ Đình cuồng nhiệt",
  "🏛️ Bưu điện Thành phố - Kiến trúc Pháp cổ",
  "🏙️ Chợ Bến Thành - Biểu tượng Sài Gòn",
  "🏟️ Mỹ Đình rực lửa - Hào khí thể thao dân tộc",
  "🏛️ Dinh Độc Lập - Chứng nhân lịch sử huy hoàng", 
  "🚩 Cột cờ Lũng Cú - Hiên ngang nơi biên viễn",
  "🏯 Tháp Rùa Hồ Gươm - Hồn thiêng sông núi", 
  "🏰 Kinh thành Huế - Vẻ đẹp cung đình vĩnh cửu",
  "🏜️ Mù Cang Chải - Tuyệt tác ruộng bậc thang",
  "🌊 Vịnh Hạ Long - Kỳ quan thiên nhiên thế giới VIP",
  "🏔️ Đỉnh Fansipan - Chinh phục nóc nhà Đông Dương",
  "🌌 Vũ trụ Việt Nam - Hào quang dân tộc yêu nước", 
  "❤️ Trái tim Việt Nam - Biết ơn và Tỏa sáng"
];

export const ACCESSORIES = [
  "🚩 Cờ đỏ sao vàng lụa cao cấp", "🎖️ Huy hiệu 30/4 mạ vàng ròng", "🔫 Súng AK-47 mạ chrome bóng loáng", "🧣 Khăn rằn Nam Bộ dệt thủ công",
  "🧢 Mũ cối huyền thoại sơn bóng đẳng cấp", "🎽 Áo trấn thủ thêu chỉ vàng tinh xảo", "🔦 Đèn bão xưa ánh sáng cam ấm áp", "💌 Thư tay hoen màu thời gian quý giá",
  "📷 Máy ảnh film Leica cổ điển 1975", "🏺 Bi đông nước nhôm khắc tên anh hùng", "🗺️ Bản đồ quân sự da bò cao cấp", "🔭 Ống nhòm quân sự High-tech 8K",
  "🎋 Gậy Trường Sơn chạm khắc rồng phượng", "🕸️ Võng dù Trường Sơn siêu bền VIP", "👒 Nón lá thêu phong cảnh đất nước", "🪷 Đóa hoa sen hồng thuần khiết thơm ngát",
  "⭐ Pin cài sao vàng lấp lánh kim cương", "📰 Sấp báo cũ ngày 30/4/1975 lịch sử", "📻 Radio cổ phát tin chiến thắng vang dội", "🕶️ Kính râm phi công mạ vàng 18K",
  "💼 Vali da Luxury National Edition", "⚔️ Kiếm lệnh truyền thống Uy nghiêm", "🔔 Trống đồng thu nhỏ bằng vàng 24K", "☕ Tách cafe sứ vẽ họa tiết lính giải phóng",
  "🎻 Đàn Guitar bọc da quân đội chất lừ", "🎒 Ba lô con cóc phong cách thời thượng VIP", "📯 Tù và quân lệnh cổ xưa thiêng liêng", "📜 Bằng khen chiến công khung gỗ quý",
  "📦 Thùng đạn gỗ cổ điển sưu tầm", "🚲 Xe đạp thồ Điện Biên huyền thoại 1954", "🧤 Găng tay da đặc công tinh nhuệ", "🥾 Giày bốt quân đội cao cấp siêu bền",
  "🔦 Đèn pin thép xưa quân dụng", "🚬 Tẩu thuốc gỗ trắc chạm khảm", "📓 Sổ nhật ký chiến trường viết tay", "🖋️ Bút máy Parker cổ điển sang trọng",
  "🥘 Bát sắt quân dụng mộc mạc tri ân", "🪵 Khúc củi bếp Hoàng Cầm huyền thoại", "🏮 Đèn lồng đỏ treo cao rực rỡ", "🎋 Cành đào Hà Nội ngày tết hòa bình",
  "🧺 Giỏ tre đựng hoa ban Điện Biên", "🧴 Lọ dầu gió xanh xưa kỷ niệm", "🧶 Khăn len đan tay mẹ gửi", "🐚 Vỏ ốc biển Trường Sa vang vọng",
  "🪖 Mũ phi công da thật cao cấp", "🧣 Khăn choàng lụa đỏ rực rỡ", "📿 Chuỗi hạt trầm hương cao cấp", "💎 Nhẫn vàng đúc hình sao chiến thắng", "🤳 Điện thoại mạ vàng bọc da bối cảnh cũ", "🎤 Micro bạc cổ điển thảm đỏ"
];

export const POSES = [
  "🫡 Chào cờ uy nghiêm lẫm liệt", 
  "🚩 Cầm Quốc kỳ hiên ngang trước ngực", 
  "🚩 Giương cao cờ Tổ Quốc giữa khói lửa",
  "🚩 Khoác cờ đỏ sao vàng đầy tự hào",
  "🚩 Phất cờ trên cao đầy kiêu hãnh", 
  "🕴️ Đứng nghiêm trang nhìn thẳng camera", 
  "🧘 Ngồi suy tư cạnh pháo oai hùng", 
  "🔫 Cầm súng tư thế sẵn sàng chiến đấu",
  "😊 Nụ cười chiến thắng rạng rỡ nhất", "🧗 Đứng trên tháp pháo xe tăng huyền thoại", "🔭 Nhìn xa xăm đầy hy vọng tương lai", "👋 Vẫy tay chào đồng đội thân thương", "✍️ Viết thư dưới ánh đèn dầu mờ ảo",
  "💧 Cầm bi đông nước uống vội", "🪷 Nâng niu đóa hoa sen quốc hoa", "🌳 Tựa lưng vào gốc cây cổ thụ Trường Sơn", "🧣 Quàng khăn rằn mỉm cười hiền hậu", "🎒 Đeo ba lô sẵn sàng lên đường ra trận",
  "🚛 Ngồi trên xe tải không kính anh hùng", "🧏 Quan sát qua ống nhòm quân sự", "⛰️ Đứng trước cột cờ Lũng Cú linh thiêng", "☝️ Chỉ tay về phía chân trời rạng rỡ", "💐 Ôm bó hoa ngày thống nhất 30/4",
  "🚲 Đứng cạnh xe đạp thồ Điện Biên", "🛡️ Cầm súng ngang ngực kiêu hãnh", "📰 Ngồi đọc báo cũ ngày giải phóng", "🪞 Nhìn vào gương mặt phản chiếu lịch sử", "💂 Tư thế duyệt binh uy nghiêm",
  "🤝 Bắt tay thân thiện đồng đội", "🧣 Cầm khăn rằn lau mồ hôi chiến trường", "👒 Đội mũ cối tay cầm hoa rạng rỡ", "🌫️ Dáng đứng hiên ngang giữa sương mù", "👤 Góc nghiêng thần thánh quyết tâm",
  "🎸 Ngồi gảy đàn guitar hát vang", "💃 Nhảy múa ăn mừng chiến thắng", "🕯️ Thắp nến tưởng niệm tri ân", "🗺️ Cầm bản đồ nghiên cứu chiến thuật", "🔥 Đứng giữa làn khói lửa hào hùng",
  "✈️ Tư thế bay của phi công anh hùng", "🚧 Đứng điều tiết giao thông thanh niên xung phong", "🥣 Ngồi ăn cơm bát sắt mộc mạc", "💖 Cầm thư tay áp vào ngực nỗi nhớ", "📦 Vác hòm đạn trên vai thần tốc",
  "🚙 Đứng cạnh xe JEEP giải phóng", "🙏 Tư thế cúi đầu thành kính biết ơn", "🧥 Khoác áo choàng đỏ quyền lực", "🛳️ Đứng trên tàu hải quân vững chãi", "🎯 Tư thế súng bắn tỉa tinh nhuệ",
  "🥋 Tư thế võ thuật cổ truyền Việt Nam", "🌸 Đứng giữa rừng hoa ban trắng xóa", "💡 Cầm đèn bão trong đêm sương", "👠 Quảng cáo quốc phục trên thảm đỏ", "💼 Tư thế Boss lãnh đạo tầm vóc"
];
