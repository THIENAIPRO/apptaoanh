import React, { useState, useRef, useEffect } from 'react';
import { GoogleGenAI } from '@google/genai';
import { UploadCloud, Sparkles, Download, Loader2, ArrowLeft, ChevronRight, LogIn, LogOut, User as UserIcon, History } from 'lucide-react';
import { THEMES, SUB_CONCEPTS, ACCESSORIES, POSES, MENS_WEAR, WOMENS_WEAR, BACKGROUNDS } from './themes';
import { auth, signInWithGoogle, logOut, db, storage } from './firebase';
import { onAuthStateChanged, User } from 'firebase/auth';
import { collection, addDoc, query, where, orderBy, onSnapshot, serverTimestamp, limit } from 'firebase/firestore';
import { ref, uploadString, getDownloadURL } from 'firebase/storage';

interface HistoryItem {
  id: string;
  imageUrl: string;
  prompt: string;
  themeTitle: string;
  concept: string;
  createdAt: any;
}

const ASPECT_RATIOS = ["9:16 (Story - Default)", "1:1 (Square)", "16:9 (Cinematic)", "4:3 (Portrait)", "3:4 (Social)"];
const IMAGE_COUNTS = ["1 Ảnh", "2 Ảnh", "3 Ảnh", "4 Ảnh"];
const STYLES = ["⛔ Không chọn", "💎 Siêu thực Đẳng cấp (Ultra Realism)", "🎥 Điện ảnh Hollywood Cinematic VIP", "🎨 Tranh sơn dầu Epic Masterpiece", "🎞️ Hình film cổ điển Documentary 1975", "✨ Render 3D Unreal Engine 5 Gold", "🔍 Macro 8K Sharpness VIP", "🌟 Fantasy National Legend Art", "🖤 Trắng đen Hào khí Bất tử", "🖌️ Thư pháp đương đại Gold Calligraphy"];

export default function App() {
  const [user, setUser] = useState<User | null>(null);
  const [images, setImages] = useState<File[]>([]);
  const [selectedThemeId, setSelectedThemeId] = useState<number | null>(null);
  const [selectedConcept, setSelectedConcept] = useState<string>("");
  const [selectedAccessory, setSelectedAccessory] = useState(ACCESSORIES[0]);
  const [selectedPose, setSelectedPose] = useState(POSES[0]);
  
  const [mensWear, setMensWear] = useState(MENS_WEAR[0]);
  const [womensWear, setWomensWear] = useState(WOMENS_WEAR[0]);
  const [style, setStyle] = useState(STYLES[0]);
  const [background, setBackground] = useState(BACKGROUNDS[0]);
  const [aspectRatio, setAspectRatio] = useState(ASPECT_RATIOS[0]);
  const [imageCount, setImageCount] = useState(IMAGE_COUNTS[0]);
  const [prompt, setPrompt] = useState("");
  
  const [isGenerating, setIsGenerating] = useState(false);
  const [generationStatus, setGenerationStatus] = useState("");
  const [generatedResults, setGeneratedResults] = useState<string[]>([]);
  const [history, setHistory] = useState<HistoryItem[]>([]);
  const [isLoadingHistory, setIsLoadingHistory] = useState(true);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Effects for Background Embers
  const [embers, setEmbers] = useState<{ id: number, left: string, duration: string, drift: string, size: string }[]>([]);
  useEffect(() => {
    const newEmbers = Array.from({ length: 30 }).map((_, i) => ({
      id: i,
      left: `${Math.random() * 100}%`,
      duration: `${5 + Math.random() * 8}s`,
      drift: `${(Math.random() - 0.5) * 300}px`,
      size: `${2 + Math.random() * 3}px`
    }));
    setEmbers(newEmbers);
  }, []);

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, (currentUser) => {
      setUser(currentUser);
      if (currentUser) {
        // Load history
        const q = query(
          collection(db, 'creations'),
          where('userId', '==', currentUser.uid),
          orderBy('createdAt', 'desc'),
          limit(20)
        );
        
        const unsubHistory = onSnapshot(q, (snapshot) => {
          const items = snapshot.docs.map(doc => ({
            id: doc.id,
            ...doc.data()
          })) as HistoryItem[];
          setHistory(items);
          setIsLoadingHistory(false);
        }, (err) => {
          console.error("History fetch error:", err);
          setIsLoadingHistory(false);
        });
        
        return () => unsubHistory();
      } else {
        setHistory([]);
        setIsLoadingHistory(false);
      }
    });
    return () => unsubscribe();
  }, []);

  const selectedTheme = THEMES.find(t => t.id === selectedThemeId);
  const currentSubConcepts = selectedThemeId ? SUB_CONCEPTS[selectedThemeId] : [];

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files) {
      setImages(Array.from(e.target.files));
    }
  };

  const fileToBase64 = (file: File): Promise<string> => {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.readAsDataURL(file);
      reader.onload = () => resolve(reader.result as string);
      reader.onerror = error => reject(error);
    });
  };

  const generateImages = async () => {
    if (images.length === 0) {
      alert("Vui lòng tải lên ít nhất một tấm ảnh gốc để AI có thể giữ khuôn mặt bạn chính xác!");
      return;
    }

    setIsGenerating(true);
    setGenerationStatus("BẮT ĐẦU KHỞI TẠO SIÊU PHẨM...");
    setGeneratedResults([]);
    
    try {
      const geminiApiKey = process.env.GEMINI_API_KEY;
      if (!geminiApiKey) {
        throw new Error("Hệ thống chưa cấu hình GEMINI_API_KEY. Vui lòng liên hệ Admin.");
      }
      const ai = new GoogleGenAI({ apiKey: geminiApiKey });

      setGenerationStatus("ĐANG TỐI ƯU HÓA SIÊU TỐC...");
      // Parallelize image encoding for maximum speed
      const imageParts = await Promise.all(images.map(async (file) => {
        const base64 = await fileToBase64(file);
        return {
          inlineData: {
            data: base64.split(',')[1],
            mimeType: file.type
          }
        };
      }));

      const promptText = `Tạo ảnh chân dung siêu phẩm nghệ thuật BIẾT ƠN VIỆT NAM - SIÊU CAO CẤP, SIÊU ĐẲNG CẤP, SIÊU ĐẸP.
[YÊU CẦU ĐẶC BIỆT TỪ NGƯỜI DÙNG]: ${prompt || "Không có mô tả thêm"}. AI PHẢI ƯU TIÊN THỰC HIỆN YÊU CẦU NÀY TRƯỚC.

CHỦ THỂ: Chính nhân vật trong ảnh gốc (người Việt Nam), đạt chuẩn ULTRA FACELOCK 100% với khóa hình học khuôn mặt tuyệt đối, giữ nguyên chính xác 100% đặc điểm nhận dạng. TẬP TRUNG TỐI ĐA VÀO ĐỘ CHÂN THỰC (REALISM) CỦA GƯƠNG MẶT VÀ LÀN DA.
BIỂU CẢM: Thần thái rạng ngời, ánh mắt đầy tự hào, nụ cười vui vẻ, hạnh phúc và lòng biết ơn sâu sắc dân tộc.

TRANG PHỤC & PHONG CÁCH (PHẢI THEO SÁT LỰA CHỌN):
- CONCEPT GỢI Ý: ${selectedConcept || "Mặc định hào hùng"}.
- PHONG CÁCH NGHỆ THUẬT: ${style}.
- TRANG PHỤC NAM: ${mensWear}.
- TRANG PHỤC NỮ: ${womensWear}.
- [YÊU CẦU TRANG PHỤC NGHIÊM NGẶT]: 
    + MÀU SẮC ĐỒNG NHẤT: Màu nào ra màu đó, TUYỆT ĐỐI KHÔNG PHA TRỘN hay làm loang màu trên cùng một trang phục. (Ví dụ: Áo đỏ là đỏ tuyền, áo trắng là trắng tinh).
    + ÁO BÀ BA: Phải đúng dáng truyền thống Việt Nam: vạt áo ngắn ngang hông, hàng cúc chạy dọc chính giữa thân áo.
    + ÁO DÀI/ÁO THUN: Nếu có "Cờ Sao Vàng" hoặc "Sao Vàng", phải thể hiện lộng lẫy, cân đối và chính diện ngay giữa ngực.
    + ĐỘ CHỈNH CHU: Trang phục phải vừa vặn hoàn hảo với vóc dáng nhân vật, không nhăn nhúm, thể hiện sự cao cấp, sang trọng bậc nhất (VIP PRO).
- [CỰC KỲ QUAN TRỌNG]: TUYỆT ĐỐI KHÔNG CÓ BẤT KỲ CHỮ VIẾT, VĂN BẢN (TEXT) NÀO TRÊN ẢNH.
- [DÁNG CHỤP & BIỂU CẢM (ƯU TIÊN HÀNG ĐẦU)]: 
    + NẾU CÓ LÁ CỜ TỔ QUỐC: Nhân vật phải cầm cờ với tư thế CỰC KỲ UY NGHIÊM, trang trọng, lẫm liệt nhất. 
    + Cử chỉ và hành động phải chuẩn mực, lột tả tinh thần dân tộc và niềm tự hào mãnh liệt.
- [KIỂU DÁNG BỐ CỤC TUỲ BIẾN]: Không rập khuôn.
    + Tùy biến theo chủ đề: Có thể là cảnh quan thiên nhiên hùng vĩ, di tích lịch sử tôn nghiêm, địa điểm check-in hiện đại, hoặc HÒA TRỘN ĐA TẦNG bối cảnh (quá khứ và hiện tại).
    + Sử dụng 30+ KIỂU BỐ CỤC KHÁC NHAU để mỗi lần tạo ảnh là một sự bất ngờ mới mẻ, đẳng cấp VIP PRO.
- [VIBE & HIỆU ỨNG ĐỈNH CAO]:
    + CHIẾN TRANH: Tăng cường tính khốc liệt, máy bay thả bom (B52, Fighter jets), cháy nổ kinh thiên động địa, hỏa lực ngút trời.
    + HÒA BÌNH: Sự phồn vinh rực rỡ, cao ốc chọc trời, ánh hào quang tỏa sáng.
- [GÓC MÁY HÀNG TRĂM BIẾN THỂ]: 
    + Thay đổi linh hoạt hàng trăm góc chụp chuyên nghiệp: Cận cảnh (Extreme Close-up), Trung cảnh (Medium shot), Toàn cảnh (Wide shot).
    + Góc máy đa chiều: Góc thấp (Low-angle) uy nghi, Góc cao (High-angle) bao quát, Góc nghiêng (Dutch angle).
- [BỐ CỤC CHUYÊN NGHIỆP]: Áp dụng các quy tắc bố cục nghệ thuật (Quy tắc 1/3, đường dẫn, đối xứng...) để tạo sự chỉnh chu nhất cho ứng dụng VIP.
- [ÁNH SÁNG]: Tập trung vào ÁNH HÀO QUANG (Radiant Glory) tỏa sáng từ trung tâm, mang lại cảm giác thiêng liêng, ấm áp và chân thực.
- [MÀU SẮC & CHI TIẾT]: Trang phục tuân thủ TUYỆT ĐỐI màu sắc đã chọn. 
- [TRANG PHỤC TRUYỀN THỐNG]:
    + Áo dài: Ưu tiên dáng truyền thống, trơn, chất liệu lụa cao cấp.
    + Áo Bà Ba: Đúng dáng vạt ngắn ngang hông, hàng cúc chạy dọc chính giữa.
- TUYỆT ĐỐI KHÔNG CÓ: Huy hiệu, quân hàm, huân chương quân sự.

HÌNH ẢNH QUY MÔ LỚN:
- [ĐỊA ĐIỂM]: BẤT KỂ BỐI CẢNH NÀO CŨNG PHẢI LÀ TẠI VIỆT NAM. 
- [BỐI CẢNH CHI TIẾT]: ${background}. 
- PHỤ KIỆN: ${selectedAccessory}.
- DÁNG CHỤP: ${selectedPose}.
- CHẤT LƯỢNG: 8K Ultra Sharp, SIÊU CẤP VIP PRO, mang bản sắc dân tộc yêu nước rực cháy.`;

      const contents = {
        parts: [
          ...imageParts,
          { text: promptText }
        ]
      };

      const mappedAspectRatio = aspectRatio.split(' ')[0];
      const count = parseInt(imageCount.split(' ')[0]);

      setGenerationStatus(`ĐANG TẠO ${count} SIÊU PHẨM (GEMINI VIP)...`);
      
      const promises = Array.from({ length: count }).map(() => 
        ai.models.generateContent({
          model: 'gemini-2.5-flash-image',
          contents: contents,
          config: {
            imageConfig: {
              aspectRatio: mappedAspectRatio
            }
          }
        })
      );

      const results = await Promise.all(promises);
      
      setGenerationStatus("ĐANG XUẤT BẢN KẾT QUẢ...");
      const newImages: string[] = [];
      for (const response of results) {
        for (const candidate of response.candidates || []) {
          for (const part of candidate.content?.parts || []) {
            if (part.inlineData) {
              newImages.push(`data:${part.inlineData.mimeType};base64,${part.inlineData.data}`);
            }
          }
        }
      }

      if (newImages.length === 0) {
        throw new Error("AI không trả về hình ảnh. Có thể do chính sách an toàn hoặc lỗi mạng.");
      }

      // HIỂN THỊ KẾT QUẢ NGAY LẬP TỨC CHO NGƯỜI DÙNG
      setGeneratedResults(newImages);
      setIsGenerating(false);
      setGenerationStatus("");

      // LƯU VÀO LỊCH SỬ (CHẠY NGẦM, KHÔNG LÀM TREO NÚT BẤM)
      if (user) {
        const savePromises = newImages.map(async (imgBase64, i) => {
          const timestamp = Date.now();
          const storagePath = `creations/${user.uid}/${timestamp}_${i}.png`;
          const storageRef = ref(storage, storagePath);
          
          await uploadString(storageRef, imgBase64, 'data_url');
          const downloadUrl = await getDownloadURL(storageRef);

          await addDoc(collection(db, 'creations'), {
            userId: user.uid,
            imageUrl: downloadUrl,
            prompt: promptText,
            themeTitle: selectedTheme?.title || "",
            concept: selectedConcept,
            createdAt: serverTimestamp()
          });
        });
        
        // Không dùng await ở đây để không chặn UI, hoặc dùng catch để tránh lỗi ngầm
        Promise.all(savePromises).catch(err => console.error("Lỗi lưu lịch sử:", err));
      }

    } catch (err: any) {
      console.error(err);
      alert(`LỖI: ${err.message || "Đã xảy ra lỗi không xác định"}`);
      setIsGenerating(false);
      setGenerationStatus("");
    }
  };

  const downloadProjectHtml = () => {
    // Encapsulate all data into JSON for the standalone file
    const appData = { THEMES, SUB_CONCEPTS, ACCESSORIES, POSES, MENS_WEAR, WOMENS_WEAR, BACKGROUNDS };
    const htmlContent = `
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>BIẾT ƠN VIỆT NAM - STANDALONE MASTER PACKAGE</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://unpkg.com/react@18/umd/react.production.min.js"></script>
    <script src="https://unpkg.com/react-dom@18/umd/react-dom.production.min.js"></script>
    <script src="https://unpkg.com/@babel/standalone/babel.min.js"></script>
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;900&display=swap');
        body { background: #020202; color: #fff; font-family: 'Inter', sans-serif; overflow-x: hidden; }
        .hero-gradient { background: linear-gradient(135deg, #C8102E 0%, #FFD700 100%); -webkit-background-clip: text; -webkit-text-fill-color: transparent; filter: drop-shadow(0 0 20px rgba(255, 215, 0, 0.5)); }
        .glass { background: rgba(255, 255, 255, 0.02); backdrop-filter: blur(25px); border: 1px solid rgba(255, 255, 255, 0.05); }
        .neon-border { border: 1px solid rgba(200, 16, 46, 0.8); box-shadow: 0 0 40px rgba(200, 16, 46, 0.4); }
        .gold-glow { box-shadow: 0 0 40px rgba(255, 215, 0, 0.3); }
        .btn-main { background: linear-gradient(to right, #C8102E, #8B0000); color: white; transition: all 0.4s; font-weight: 900; border: 1px solid gold; box-shadow: 0 0 30px rgba(200, 16, 46, 0.6); }
        .btn-main:hover { transform: translateY(-5px); box-shadow: 0 10px 50px rgba(255, 215, 0, 0.8); }
    </style>
</head>
<body class="p-4 md:p-8">
    <div id="root"></div>

    <script type="text/babel">
        const { useState } = React;
        const APP_DATA = ${JSON.stringify(appData)};

        function App() {
            const [selectedTheme, setSelectedTheme] = useState(null);
            
            return (
                <div className="max-w-7xl mx-auto flex flex-col items-center gap-16 py-12">
                    <header className="text-center animate-pulse flex flex-col items-center">
                        <img src="https://i.postimg.cc/F1cjWYG6/LOGO-VUA-APP-(1).png" alt="VIP Logo" style={{ width: '100px', height: '100px', borderRadius: '50%', border: '2px solid gold', boxShadow: '0 0 30px gold', marginBottom: '20px' }} />
                        <h1 className="text-5xl md:text-9xl font-black hero-gradient uppercase tracking-tighter flex flex-col md:block">
                            <span>BIẾT ƠN</span> <span>VIỆT NAM</span>
                        </h1>
                        <p className="text-yellow-500 font-bold tracking-[0.3em] text-lg mt-4 italic">HUYỀN THOẠI NGÀN NĂM (100% COMPLETE)</p>
                    </header>

                    <div className="w-full glass p-10 md:p-20 rounded-[60px] neon-border text-center flex flex-col items-center gap-10">
                        <div className="text-5xl">🇻🇳</div>
                        <h2 className="text-4xl font-black uppercase text-red-600">Đã Kích Hoạt Hệ Thống VIP</h2>
                        <p className="text-gray-400 max-w-2xl text-lg leading-relaxed">
                            Bản master đã sẵn sàng để triển khai. 
                            Hãy cài đặt Domain của bạn và cung cấp API Key để khởi chạy cỗ máy tri ân dân tộc.
                        </p>
                        
                        <div className="grid grid-cols-2 md:grid-cols-4 gap-6 w-full mt-10">
                            <div className="glass p-8 rounded-3xl border-white/5 shadow-[0_0_20px_rgba(255,215,0,0.1)]">
                                <h4 className="text-yellow-500 font-bold mb-2">20 THEMES</h4>
                                <p className="text-[10px] text-gray-500">Lịch sử oai hùng</p>
                            </div>
                            <div className="glass p-8 rounded-3xl border-white/5 shadow-[0_0_20px_rgba(255,215,0,0.1)]">
                                <h4 className="text-yellow-500 font-bold mb-2">400 CONCEPTS</h4>
                                <p className="text-[10px] text-gray-500">Gợi ý tạo ảnh</p>
                            </div>
                            <div className="glass p-8 rounded-3xl border-white/5 shadow-[0_0_20px_rgba(255,215,0,0.1)]">
                                <h4 className="text-yellow-500 font-bold mb-2">100+ WEAR</h4>
                                <p className="text-[10px] text-gray-500">Quốc phục</p>
                            </div>
                            <div className="glass p-8 rounded-3xl border-white/5 shadow-[0_0_20px_rgba(255,215,0,0.1)]">
                                <h4 className="text-yellow-500 font-bold mb-2">50+ BG</h4>
                                <p className="text-[10px] text-gray-500">Bối cảnh xưa</p>
                            </div>
                        </div>

                        <button className="btn-main px-16 py-6 rounded-full text-2xl uppercase tracking-widest mt-10">
                            NGHÌN NĂM KHÔNG QUÊN
                        </button>
                    </div>

                    <div className="grid grid-cols-2 md:grid-cols-5 gap-4 w-full">
                        {APP_DATA.THEMES.map(t => (
                            <div key={t.id} className="glass p-6 rounded-3xl border-white/5 flex flex-col items-center gap-2 hover:neon-border transition-all">
                                <span className="text-3xl">{t.emoji}</span>
                                <span className="text-[10px] font-bold text-center uppercase tracking-tighter text-gray-400">{t.title}</span>
                            </div>
                        ))}
                    </div>

                    <div className="w-full max-w-7xl border-t border-white/10 pt-16 flex flex-col items-center gap-8 mt-10">
                        <p style={{ textShadow: '0 0 20px red', color: 'white', fontWeight: 900, textAlign: 'center', fontSize: '24px' }}>
                            ĐÂY LÀ APP CỦA THIỆN VUA APP NGHIÊM CẤM SAO CHÉP BẤT HỢP PHÁP
                        </p>
                        <div className="text-center text-[10px] text-gray-800 uppercase tracking-[0.5em]">
                            Copyright © 2026 BIẾT ƠN VIỆT NAM - NGƯỜI SÁNG LẬP: NGUYỄN QUỐC THIỆN
                        </div>
                    </div>
                </div>
            );
        }

        ReactDOM.createRoot(document.getElementById('root')).render(<App />);
    </script>
</body>
</html>`;
    const blob = new Blob([htmlContent], { type: 'text/html' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'LICH_SU_BIET_ON_STANDALONE_WEB_APP.html';
    a.click();
  };

  if (!user) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center p-6 bg-dark-hero gap-12 text-center">
        <div className="animate-hero-pulse flex flex-col items-center gap-6">
          <img src="https://i.postimg.cc/F1cjWYG6/LOGO-VUA-APP-(1).png" alt="Logo" className="w-48 h-48 rounded-full neon-logo mb-6" />
          <h1 className="text-6xl md:text-8xl font-black uppercase tracking-tighter text-victory-gradient">BIẾT ƠN VIỆT NAM</h1>
          <p className="text-vietnam-gold font-bold tracking-[0.4em] text-xl">XÁC THỰC DANH TÍNH VIP</p>
        </div>
        <button 
          onClick={signInWithGoogle}
          className="flex items-center gap-6 bg-white text-black px-12 py-6 rounded-[30px] font-black text-2xl hover:scale-110 transition-all shadow-[0_0_50px_rgba(255,255,255,0.3)]"
        >
          <img src="https://www.google.com/favicon.ico" className="w-8 h-8" alt="Google" />
          ĐĂNG NHẬP BẰNG GOOGLE
        </button>
      </div>
    );
  }

  return (
    <div className="min-h-screen p-6 md:p-12 lg:p-16 flex flex-col items-center gap-16 pb-32 relative overflow-hidden">
      
      {/* Cinematic Battlefield Background Layer */}
      <div className="fixed inset-0 pointer-events-none z-[-1] overflow-hidden">
        {/* Soldier Silhouette & Action Layer */}
        <div className="absolute inset-0 opacity-20 bg-[url('https://images.unsplash.com/photo-1590424753858-394a129304bc?q=80&w=1974&auto=format&fit=crop')] bg-cover bg-center mix-blend-overlay"></div>
        
        {/* Floating Embers */}
        {embers.map(e => (
          <div 
            key={e.id}
            className="ember"
            style={{ 
              left: e.left, 
              width: e.size, 
              height: e.size,
              '--duration': e.duration,
              '--drift': e.drift
            } as any}
          />
        ))}

        {/* Smoke & Vignette */}
        <div className="absolute inset-0 bg-radial-gradient(circle at 50% 50%, transparent, rgba(0,0,0,0.7)) mix-blend-multiply"></div>
      </div>

      {/* Auth Control (Top Right) */}
      <div className="fixed top-6 right-6 z-50 flex items-center gap-4">
        <div className="hidden md:flex items-center gap-3 bg-black/60 p-2 pr-6 rounded-full border border-white/10 backdrop-blur-md">
          {user.photoURL ? (
            <img src={user.photoURL} className="w-10 h-10 rounded-full border border-vietnam-gold/50" alt="Avatar" />
          ) : (
            <div className="w-10 h-10 rounded-full bg-slate-800 flex items-center justify-center border border-vietnam-gold/50">
              <UserIcon size={20} className="text-vietnam-gold" />
            </div>
          )}
          <span className="text-white font-bold text-xs">{user.displayName}</span>
        </div>
        <button 
          onClick={logOut}
          className="p-3 bg-red-900/40 border border-red-500/50 rounded-full text-red-500 hover:bg-red-500 hover:text-white transition-all shadow-lg"
          title="Đăng xuất"
        >
          <LogOut size={24} />
        </button>
      </div>

      {/* 1. Header & Upload */}
      <div className="w-full min-h-[50vh] flex flex-col justify-center items-center gap-12 mt-10">
        <div className="text-center animate-hero-pulse flex flex-col items-center">
          {/* VIP Logo (Centered) */}
          <img 
            src="https://i.postimg.cc/F1cjWYG6/LOGO-VUA-APP-(1).png" 
            alt="VIP Logo" 
            className="w-32 h-32 md:w-48 md:h-48 rounded-full neon-logo mb-10 hover:scale-110 transition-transform cursor-pointer" 
          />
          
          <h1 className="text-4xl md:text-7xl lg:text-8xl font-black uppercase tracking-tighter text-victory-gradient mb-4 filter drop-shadow-[0_0_30px_rgba(255,215,0,0.6)] flex flex-col md:block leading-tight md:scale-100 scale-[1.2]">
            <span className="md:inline">BIẾT ƠN</span>
            <span className="md:inline"> VIỆT NAM</span>
          </h1>
          <h2 className="text-base md:text-2xl lg:text-3xl text-vietnam-gold font-bold uppercase tracking-[0.3em] drop-shadow-[0_0_15px_rgba(255,215,0,0.5)] italic">
            HUYỀN THOẠI NGÀN NĂM
          </h2>
          
          {/* Social Links Section (Simplified) */}
          <div className="mt-8 glass p-6 md:p-8 rounded-[40px] border-2 border-vietnam-red/40 shadow-[0_0_50px_rgba(200,16,46,0.2)] max-w-2xl w-full">
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 w-full">
              <a href="https://www.tiktok.com/@thienvuaapp?_r=1&_t=ZS-95eqStaVBZ7" target="_blank" rel="noreferrer" className="glass p-4 rounded-2xl flex items-center justify-center gap-2 hover:bg-white/10 hover:border-white/30 transition-all group">
                <span className="font-bold text-xs md:text-sm group-hover:text-vietnam-gold">TIKTOK</span>
              </a>
              <a href="https://www.youtube.com/@NGUY%E1%BB%84NQU%E1%BB%90CTHI%E1%BB%86NAI" target="_blank" rel="noreferrer" className="glass p-4 rounded-2xl flex items-center justify-center gap-2 hover:bg-white/10 hover:border-white/30 transition-all group">
                <span className="font-bold text-xs md:text-sm group-hover:text-vietnam-gold">YOUTUBE</span>
              </a>
              <a href="https://www.facebook.com/nguyen.quocthien.58" target="_blank" rel="noreferrer" className="glass p-4 rounded-2xl flex items-center justify-center gap-2 hover:bg-white/10 hover:border-white/30 transition-all group">
                <span className="font-bold text-xs md:text-sm group-hover:text-vietnam-gold">FACEBOOK</span>
              </a>
              <a href="https://zalo.me/g/auvzpn118" target="_blank" rel="noreferrer" className="glass p-4 rounded-2xl flex items-center justify-center gap-2 bg-red-900/40 border-red-500/50 hover:bg-red-800/60 transition-all group">
                <span className="font-black text-[10px] md:text-xs text-yellow-400 group-hover:scale-110 transition-transform">X8 APP VIP</span>
              </a>
            </div>
          </div>
        </div>

        <div 
          onClick={() => fileInputRef.current?.click()}
          className="group w-full max-w-7xl h-auto min-h-[110px] md:min-h-[160px] flex flex-col items-center justify-center p-4 md:p-6 bg-vietnam-red/5 border-2 border-dashed border-vietnam-red/40 rounded-3xl shadow-[0_0_40px_rgba(200,16,46,0.15)] hover:shadow-[0_0_60px_rgba(200,16,46,0.3)] cursor-pointer transition-all duration-300 relative overflow-hidden"
        >
          <input 
            type="file" 
            ref={fileInputRef}
            multiple 
            accept="image/*"
            style={{ display: 'none' }}
            onChange={handleImageUpload} 
          />
          {images.length > 0 ? (
             <div className="flex flex-wrap gap-6 items-center justify-center w-full">
               {images.map((img, i) => (
                 <img key={i} src={URL.createObjectURL(img)} alt={`Upload ${i}`} className="h-32 object-contain rounded-xl shadow-lg border border-vietnam-red/50 group-hover:scale-105 transition-transform duration-300" />
               ))}
             </div>
          ) : (
             <div className="flex flex-col items-center gap-4 text-vietnam-red/90 group-hover:text-vietnam-red">
                <UploadCloud size={80} className="group-hover:-translate-y-2 transition-transform duration-500" />
                <p className="text-3xl font-black uppercase tracking-widest text-center">Tải Lên Ảnh Gốc Của Bạn (Facelock 100%)</p>
                <p className="text-lg font-medium text-white/40 uppercase tracking-widest italic">Hỗ trợ nhiều góc độ ảnh để đạt độ chính xác tối thượng</p>
             </div>
          )}
        </div>
      </div>

      {/* 2. Theme Selection or Sub-Concept Selection */}
      <div className="w-full max-w-7xl scroll-mt-20" id="selection-area">
        {!selectedThemeId ? (
          <>
            <h3 className="text-4xl font-black mb-10 text-vietnam-gold uppercase tracking-widest text-center drop-shadow-xl">
               1. LỰA CHỌN CHỦ ĐỀ CHIẾN DỊCH (20 THEMES)
            </h3>
            <div className="grid grid-cols-2 lg:grid-cols-5 gap-6">
              {THEMES.map((theme) => (
                <button
                  key={theme.id}
                  onClick={() => { setSelectedThemeId(theme.id); setSelectedConcept(""); }}
                  className={`group p-4 md:p-6 rounded-3xl flex flex-col items-center gap-2 md:gap-3 text-center transition-all duration-500 ${
                    selectedThemeId === theme.id ? 'neon-card-selected-red' : 'neon-card-red'
                  }`}
                >
                  <span className="text-4xl md:text-5xl mb-1 group-hover:scale-125 transition-transform duration-500">{theme.emoji}</span>
                  <span className="text-lg md:text-xl font-black uppercase tracking-tighter text-white group-hover:text-vietnam-gold transition-colors">{theme.title}</span>
                  <span className="text-[10px] text-gray-500 font-bold leading-tight opacity-0 group-hover:opacity-100 transition-opacity uppercase tracking-tighter">{theme.desc}</span>
                </button>
              ))}
            </div>
          </>
        ) : (
          <div className="flex flex-col items-center gap-10">
            <div className="w-full flex items-center justify-between bg-victory-glass p-6 rounded-3xl border border-vietnam-gold/20">
              <button 
                onClick={() => { setSelectedThemeId(null); setSelectedConcept(""); }}
                className="flex items-center gap-3 text-vietnam-gold font-black uppercase tracking-widest hover:text-white transition-colors"
              >
                <ArrowLeft size={24} /> Quay lại Chủ đề
              </button>
              <div className="flex items-center gap-4">
                <span className="text-4xl">{selectedTheme?.emoji}</span>
                <span className="text-3xl font-black uppercase text-victory-gradient tracking-widest">{selectedTheme?.title}</span>
              </div>
              <div className="w-24"></div>
            </div>

            <h3 className="text-4xl font-black text-vietnam-gold uppercase tracking-widest text-center drop-shadow-xl">
               2. CHỌN CONCEPT CHI TIẾT (20 CONCEPTS)
            </h3>
            
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 w-full">
              {currentSubConcepts.map((concept, i) => (
                <button
                  key={i}
                  onClick={(e) => {
                    e.stopPropagation();
                    setSelectedConcept(concept);
                  }}
                  className={`p-4 md:p-6 rounded-2xl border-2 transition-all duration-300 text-left flex items-center justify-between relative group ${
                    selectedConcept === concept 
                      ? 'neon-card-selected-gold text-white' 
                      : 'neon-card-gold border-white/10 text-gray-400'
                  }`}
                >
                  <div className="flex flex-col gap-1">
                    {selectedConcept === concept && <span className="text-[10px] font-black text-vietnam-red mb-1 animate-pulse">● ĐÃ CHỌN VIP</span>}
                    <span className="text-lg font-bold uppercase tracking-wide leading-tight">{concept}</span>
                  </div>
                  <ChevronRight size={20} className={selectedConcept === concept ? 'text-vietnam-red' : 'text-gray-600'} />
                </button>
              ))}
            </div>
          </div>
        )}
      </div>

      {/* 3. Custom Attributes Grid */}
      <div className="w-full max-w-7xl grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
        <FieldSelect label="🧣 Phụ Kiện Cầm Tay (50)" value={selectedAccessory} options={ACCESSORIES} onChange={setSelectedAccessory} neonColor="rgba(200,16,46,0.6)" />
        <FieldSelect label="🕺 Dáng Chụp / Thần Thái (50)" value={selectedPose} options={POSES} onChange={setSelectedPose} neonColor="rgba(255,215,0,0.6)" />
        <FieldSelect label="👔 Quân Phục / Nam" value={mensWear} options={MENS_WEAR} onChange={setMensWear} neonColor="rgba(200,16,46,0.6)" />
        <FieldSelect label="👗 Áo Dài / Nữ" value={womensWear} options={WOMENS_WEAR} onChange={setWomensWear} neonColor="rgba(255,215,0,0.6)" />
        <FieldSelect label="🎨 Thẩm Mỹ Tầng Thứ" value={style} options={STYLES} onChange={setStyle} neonColor="rgba(200,16,46,0.6)" />
        <FieldSelect label="🌆 Bối Cảnh Lịch Sử" value={background} options={BACKGROUNDS} onChange={setBackground} neonColor="rgba(255,215,0,0.6)" />
        <FieldSelect label="📐 Định Dạng Poster" value={aspectRatio} options={ASPECT_RATIOS} onChange={setAspectRatio} neonColor="rgba(200,16,46,0.6)" />
        <FieldSelect label="🔢 Bản Sao Biểu Tượng" value={imageCount} options={IMAGE_COUNTS} onChange={setImageCount} neonColor="rgba(255,215,0,0.6)" />
      </div>

      {/* 4. Prompt & Generate */}
      <div className="w-full max-w-7xl flex flex-col gap-10 mt-6 bg-black/40 p-8 md:p-12 rounded-[50px] border border-white/5 shadow-2xl">
        <input 
          type="text" 
          placeholder="Mô tả bối cảnh cực đoan hơn (Pháo nổ, lửa cháy, xe tăng càn quét)..." 
          value={prompt}
          onChange={e => setPrompt(e.target.value)}
          className="w-full bg-black/60 border-2 border-vietnam-red/50 shadow-[0_0_30px_rgba(200,16,46,0.3)] text-white text-2xl lg:text-3xl p-8 rounded-3xl outline-none focus:border-vietnam-gold focus:shadow-[0_0_50px_rgba(255,215,0,0.5)] transition-all duration-300 placeholder-white/20 italic"
        />

        <button 
          onClick={(e) => {
            e.preventDefault();
            generateImages();
          }}
          disabled={isGenerating || !selectedThemeId}
          className="group w-full py-5 bg-gradient-to-r from-red-700 via-red-900 to-red-700 rounded-[50px] border-2 border-vietnam-gold shadow-[0_0_80px_rgba(200,16,46,0.6)] hover:shadow-[0_0_150px_rgba(255,215,0,0.8)] flex flex-col items-center justify-center gap-2 transition-all duration-500 hover:scale-[1.03] active:scale-95 disabled:opacity-30"
        >
          {isGenerating ? (
            <Loader2 className="animate-spin text-vietnam-gold w-16 h-16" />
          ) : (
            <Sparkles className="text-vietnam-gold w-20 h-20 group-hover:rotate-180 transition-transform duration-1000" />
          )}
          <span className="text-5xl lg:text-8xl font-black uppercase tracking-[0.25em] text-white drop-shadow-[0_4px_30px_rgba(0,0,0,0.9)]">
            {isGenerating ? "KHỞI TẠO..." : "NGHÌN NĂM KHÔNG QUÊN"}
          </span>
          {isGenerating && <p className="text-white font-bold animate-pulse uppercase tracking-[0.2em]">{generationStatus}</p>}
          {!isGenerating && <p className="text-vietnam-gold/60 font-bold uppercase tracking-widest text-sm group-hover:text-vietnam-gold transition-colors">PHIÊN BẢN BIỂU TƯỢNG QUỐC GIA</p>}
        </button>
        {!selectedThemeId && <p className="text-center text-vietnam-gold font-bold uppercase animate-pulse">Vui lòng chọn chủ đề để khởi động cỗ máy</p>}
      </div>

      {/* 5. Results Area */}
      {generatedResults.length > 0 && (
        <div className="w-full max-w-7xl flex flex-col items-center gap-12 mt-12 bg-victory-glass p-12 rounded-[50px] shadow-[0_0_150px_rgba(0,0,0,0.9)] border border-vietnam-gold/10">
          <h3 className="text-5xl font-black uppercase text-victory-gradient tracking-widest text-center">
            SIÊU PHẨM BIỂU TƯỢNG QUỐC GIA
          </h3>
          <div className="flex gap-12 overflow-x-auto w-full pb-10 justify-center items-start">
            {generatedResults.map((img, i) => (
              <div key={i} className="flex flex-col items-center gap-8 shrink-0 group relative">
                <div className="p-3 bg-gradient-to-br from-vietnam-red via-vietnam-gold to-vietnam-red rounded-[30px] shadow-[0_0_60px_rgba(255,215,0,0.4)] hover:scale-105 transition-transform duration-500">
                  <img src={img} alt={`Result ${i}`} className="max-h-[800px] object-contain rounded-2xl bg-black" />
                </div>
                <a 
                  href={img} 
                  download={`legendary_vietnam_icon_${i}.png`} 
                  className="flex items-center gap-4 bg-vietnam-gold text-black px-12 py-6 rounded-full font-black text-3xl tracking-widest shadow-[0_0_40px_rgba(255,215,0,0.7)] hover:scale-110 transition-transform duration-500 hover:bg-gold-bright"
                >
                  <Download size={40} />
                  XUẤT BẢN 8K VIP
                </a>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* 6. History Area (Thumbnails) */}
      {history.length > 0 && (
        <div className="w-full max-w-7xl flex flex-col gap-8 mt-12 bg-black/30 p-8 md:p-12 rounded-[50px] border border-white/5">
          <div className="flex items-center justify-between w-full border-b border-white/10 pb-6">
            <div className="flex items-center gap-4">
              <History size={32} className="text-vietnam-gold" />
              <h3 className="text-3xl font-black uppercase text-white tracking-widest">LỊCH SỬ VIP</h3>
            </div>
            <span className="text-xs font-bold text-gray-500 uppercase tracking-widest">Lưu trữ vĩnh viễn ({history.length} mục)</span>
          </div>
          
          <div className="flex gap-4 overflow-x-auto pb-4 scrollbar-thin">
            {history.map((item) => (
              <div key={item.id} className="group relative min-w-[120px] md:min-w-[150px] aspect-[3/4] rounded-2xl overflow-hidden border border-white/10 hover:border-vietnam-gold/50 transition-all duration-300 shadow-xl">
                 <img src={item.imageUrl} alt="History Thumbnail" className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500" />
                 <div className="absolute inset-0 bg-black/80 opacity-0 group-hover:opacity-100 transition-opacity flex flex-col items-center justify-center p-2 gap-2 text-center">
                    <p className="text-[8px] font-black text-vietnam-gold uppercase line-clamp-1">{item.themeTitle}</p>
                    <a 
                      href={item.imageUrl} 
                      download={`vietnam_legend_${item.id}.png`}
                      className="p-1.5 bg-vietnam-gold rounded-full text-black hover:scale-110 transition-transform"
                    >
                      <Download size={14} />
                    </a>
                 </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Protection Footer */}
      <div className="w-full max-w-7xl border-t-2 border-white/5 pt-16 flex flex-col items-center gap-8 mt-20">
        <p className="text-lg md:text-3xl font-black uppercase tracking-[0.5em] neon-footer text-center drop-shadow-2xl px-6 py-8 bg-black/40 rounded-[30px] border border-red-500/20 md:scale-100 scale-[0.6]">
          ĐÂY LÀ APP CỦA THIỆN VUA APP NGHIÊM CẤM SAO CHÉP BẤT HỢP PHÁP
        </p>
        <div className="flex gap-10 text-[10px] text-gray-700 font-black uppercase tracking-[0.4em]">
          <span>© 2026 THIỆN VUA APP</span>
          <span>•</span>
          <span>ALL RIGHTS RESERVED</span>
        </div>
      </div>
    </div>
  );
}

function FieldSelect({ label, value, options, onChange, neonColor }: { label: string, value: string, options: string[], onChange: (v: string) => void, neonColor: string }) {
  return (
    <div className="flex flex-col gap-5">
      <label className="text-2xl font-black uppercase tracking-widest text-vietnam-gold/80 ml-2 drop-shadow-md">
        {label}
      </label>
      <div 
        className="relative rounded-2xl transition-all duration-300 border-2 overflow-hidden shadow-inner"
        style={{ 
          borderColor: value !== options[0] ? neonColor.replace('0.6', '1') : 'rgba(255,255,255,0.1)',
          boxShadow: value !== options[0] ? `0 0 25px ${neonColor}` : 'none' 
        }}
      >
        <select 
          value={value}
          onChange={e => onChange(e.target.value)}
          className="w-full bg-black/80 text-white text-xl lg:text-2xl font-bold p-6 rounded-2xl outline-none appearance-none cursor-pointer hover:bg-black/90 transition-colors"
        >
          {options.map((opt, i) => (
            <option key={i} value={opt} className="bg-slate-950 text-white text-xl py-3">{opt}</option>
          ))}
        </select>
        <div className="absolute top-1/2 right-6 -translate-y-1/2 pointer-events-none text-vietnam-gold/50 text-3xl">
          ▼
        </div>
      </div>
    </div>
  );
}

